import React, { useState, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const attendanceData = [
  { week: 'Week 1', attendance: 85 },
  { week: 'Week 2', attendance: 90 },
  { week: 'Week 3', attendance: 88 },
  { week: 'Week 4', attendance: 95 },
  { week: 'Week 5', attendance: 92 },
  { week: 'Week 6', attendance: 97 },
];

const InfoCard = ({ title, value }) => (
  <div className="info-card">
    <h3>{title}</h3>
    <p>{value}</p>
  </div>
);

const Dashboard = () => {
  const [time, setTime] = useState(new Date());
  const [todos, setTodos] = useState([]);
  const [newTodo, setNewTodo] = useState('');

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const addTodo = () => {
    if (newTodo.trim()) {
      setTodos([...todos, newTodo.trim()]);
      setNewTodo('');
    }
  };

  return (
    <div className="dashboard">
      <header className="header">
        <h1>Student Dashboard</h1>
      </header>
      <main className="container">
        <div className="info-cards">
          <InfoCard title="Overall Attendance" value="91.2%" />
          <InfoCard title="Total Fee" value="$10,000" />
          <InfoCard title="Remaining Fee" value="$2,500" />
        </div>
        <div className="grid">
          <div className="widget">
            <h2>Clock</h2>
            <p className="clock">{time.toLocaleTimeString()}</p>
          </div>
          <div className="widget">
            <h2>To-Do List</h2>
            <ul>
              {todos.map((todo, index) => (
                <li key={index}>{todo}</li>
              ))}
            </ul>
            <input
              type="text"
              value={newTodo}
              onChange={(e) => setNewTodo(e.target.value)}
              placeholder="Add a new task"
            />
            <button onClick={addTodo}>Add</button>
          </div>
          <div className="widget full-width">
            <h2>Upcoming Deadlines</h2>
            <ul>
              <li>Math Assignment - June 15, 2024</li>
              <li>English Essay - June 20, 2024</li>
              <li>Science Project - June 25, 2024</li>
            </ul>
          </div>
          <div className="widget full-width">
            <h2>Attendance Percentage</h2>
            <div className="chart">
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={attendanceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="week" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="attendance" stroke="#000000" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

const root = createRoot(document.getElementById('root'));
root.render(<Dashboard />);