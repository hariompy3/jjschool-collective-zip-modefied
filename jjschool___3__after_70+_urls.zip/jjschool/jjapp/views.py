from django.shortcuts import render, redirect ,get_object_or_404
from django.contrib.auth import login, authenticate, logout
from .forms import *
from .decorators import *
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from .models import *
from django.contrib.auth.decorators import user_passes_test
from django.shortcuts import render
from django.contrib.auth.decorators import user_passes_test
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db.models import Q
from .models import Student

def home_page(request):
    notifications = Notification.objects.all().order_by('-created_at')
    information = "Welcome to Our School's Website! Here you'll find all the latest updates and announcements."
    return render(request, 'home.html', {'notifications': notifications, 'information': information})


def logout_view(request):
    user_role = request.user.role if request.user.is_authenticated else None
    logout(request)

    if user_role == 'student':
        return redirect('student_login')
    elif user_role == 'teacher':
        return redirect('teacher_login')
    elif user_role == 'principal':
        return redirect('principal_login')
    else:
        return redirect('home_page')
    












#principal thinks 

def principal_login(request):
    if request.method == 'POST':
        form = PrincipalForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('principal_dashboard')

    else:
        form = PrincipalForm()
    return render(request, 'principal/login.html', {'form': form})




@user_passes_test(is_principal, login_url='principal_login')
def principal_dashboard(request):
    notifications = Notification.objects.all()
    student = Student.objects. all().count()
    return render(request, 'principal/dashboard.html', {'notifications': notifications})




@user_passes_test(is_principal, login_url='principal_login')
def manage_notifications(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        content = request.POST.get('content')
        Notification.objects.create(title=title, content=content)
        return redirect('manage_notifications')
    notifications = Notification.objects.all()
    return render(request, 'principal/manage_notifications.html', {'notifications': notifications})


@user_passes_test(is_principal, login_url='principal_login')
def edit_notification(request, notification_id):
    notification = Notification.objects.get(id=notification_id)
    if request.method == 'POST':
        notification.title = request.POST.get('title')
        notification.content = request.POST.get('content')
        notification.save()
        return redirect('manage_notifications')
    return render(request, 'principal/edit_notification.html', {'notification': notification})


@user_passes_test(is_principal, login_url='principal_login')
def delete_notification(request, notification_id):
    notification = Notification.objects.get(id=notification_id)
    notification.delete()
    return redirect('manage_notifications')


@user_passes_test(is_principal, login_url='principal_login')
def list_students(request):
    search_query = request.GET.get('search', '')
    students = Student.objects.filter(is_deleted=False)

    if search_query:
        students = students.filter(
            Q(first_name__icontains=search_query) |
            Q(last_name__icontains=search_query) |
            Q(roll_number__icontains=search_query)
        )

    # Sorting
    sort_by = request.GET.get('sort', 'first_name')
    students = students.order_by(sort_by)

    # Pagination
    paginator = Paginator(students, 10)  # Show 10 students per page
    page = request.GET.get('page')
    try:
        students = paginator.page(page)
    except PageNotAnInteger:
        students = paginator.page(1)
    except EmptyPage:
        students = paginator.page(paginator.num_pages)

    context = {
        'students': students,
        'search_query': search_query,
        'sort_by': sort_by,
    }
    return render(request, 'principal/list_students.html', context)




def student_profile(request, student_id):
     student = get_object_or_404(Student, id=student_id)
     return render(request, 'principal/student_profile.html', {'student': student})



@user_passes_test(is_principal, login_url='principal_login')
def deleted_students(request):
        students = Student.objects.filter(is_deleted=True)
        return render(request, 'principal/deleted_students.html', {'students': students})


def soft_delete_student(request, student_id):
    student = get_object_or_404(Student, id=student_id)
    student.is_deleted = True
    student.save()
    return redirect('list_students')


@user_passes_test(is_principal, login_url='principal_login')
def restore_student(request, student_id):
    student = get_object_or_404(Student, id=student_id)
    student.is_deleted = False
    student.save()
    return redirect('deleted_students')


def add_student(request):
    if request.method == "POST":
        form = StudentForm(request.POST)
        if form.is_valid():
            user = request.user  
            student = form.save(commit=False)
            student.user = user  
            student.save()  
            return redirect('principal_dashboard')
    else:
        form = StudentForm()
    return render(request, 'principal/add_student.html', {'form': form})



@user_passes_test(is_principal, login_url='principal_login')
def edit_student(request, student_id):
    #student_user = get_object_or_404(Student, id=student_id)
    student = get_object_or_404(Student, id=student_id)
    
    if request.method == 'POST':
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            return redirect('list_students') 
    else:
        form = StudentForm(instance=student)
    
    return render(request, 'principal/edit_student.html', {'form': form, 'student': student})


@login_required
@user_passes_test(is_principal, login_url='principal_login')
def delete_student(request, student_id):
    student_user = get_object_or_404(CustomUser, id=student_id)
    student = get_object_or_404(Student, user=student_user)
    
    if request.method == 'POST':
        student.delete()
        return redirect('list_students')
    
    return render(request, 'principal/delete_student.html', {'student': student})



@user_passes_test(is_principal, login_url='principal_login')
def add_teacher(request):
    if request.method == 'POST':
        user_form = CustomUserForm(request.POST)
        teacher_form = TeacherPriForm(request.POST)
        
        if user_form.is_valid() and teacher_form.is_valid():
            user = user_form.save(commit=False)
            user.role = 'teacher'
            user.set_password(user_form.cleaned_data['password']) 
            user.save()
            
            teacher = teacher_form.save(commit=False)
            teacher.user = user
            teacher.save()
            
            return redirect('principal_dashboard')
        else:
            error = "Please correct the errors below."
            return render(request, 'principal/add_teacher.html', {'user_form': user_form, 'teacher_form': teacher_form, 'error': error})
    else:
        user_form = CustomUserForm()
        teacher_form = TeacherPriForm()
    return render(request, 'principal/add_teacher.html', {'user_form': user_form, 'teacher_form': teacher_form})




@user_passes_test(is_principal, login_url='principal_login')
def list_teachers(request):
    teachers = Teacher.objects.all()
    return render(request, 'principal/list_teachers.html', {'teachers': teachers})


@user_passes_test(is_principal, login_url='principal_login')
def edit_teacher(request, teacher_id):
    teacher_user = get_object_or_404(CustomUser, id=teacher_id)
    teacher = get_object_or_404(Teacher, user=teacher_user)
    
    if request.method == 'POST':
        user_form = CustomUserForm(request.POST, instance=teacher_user)
        teacher_form = TeacherForm(request.POST, instance=teacher)
        if user_form.is_valid() and teacher_form.is_valid():
            user_form.save()
            teacher_form.save()
            return redirect('list_teachers')
    else:
        user_form = CustomUserForm(instance=teacher_user)
        teacher_form = TeacherForm(instance=teacher)
    
    return render(request, 'principal/edit_teacher.html', {'user_form': user_form, 'teacher_form': teacher_form})


@user_passes_test(is_principal, login_url='principal_login')
def delete_teacher(request, teacher_id):
    teacher_user = get_object_or_404(CustomUser, id=teacher_id)
    teacher = get_object_or_404(Teacher, user=teacher_user)
    
    if request.method == 'POST':
        teacher_user.delete()
        return redirect('list_teachers')
    
    return render(request, 'principal/delete_teacher.html', {'teacher': teacher})


@user_passes_test(is_principal, login_url='principal_login')
def view_student_details(request, student_id):
    student = get_object_or_404(Student, id=student_id)
    return render(request, 'principal/view_student_details.html', {'student': student})


@user_passes_test(is_principal, login_url='principal_login')
def view_teacher_details(request, teacher_id):
    teacher = get_object_or_404(Teacher, user_id=teacher_id)
    return render(request, 'principal/view_teacher_details.html', {'teacher': teacher})


@user_passes_test(is_principal, login_url='principal_login')
def view_attendance_records(request):
    attendance_records = Attendance.objects.all()
    return render(request, 'principal/view_attendance_records.html', {'attendance_records': attendance_records})


@user_passes_test(is_principal, login_url='principal_login')
def view_performance_reports(request):
    students = Student.objects.all()
    return render(request, 'principal/view_performance_reports.html', {'students': students})




from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required, user_passes_test
from .models import Student, Attendance, Teacher
from .forms import AttendanceForm

def is_teacher(user):
    return user.is_authenticated and user.role == 'teacher'
# views.py
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from .models import Student, Attendance, Teacher
from django.contrib import messages

@user_passes_test(is_teacher, login_url='teacher_login')
def add_attendance(request):
    today = timezone.now().date()
    teacher = request.user.teacher
    students = Student.objects.filter(grade=teacher.class_teacher_of_grade).order_by('first_name', 'last_name')

    if request.method == 'POST':
        for student in students:
            status = request.POST.get(f'status_{student.pk}', '0')  # Default to '0' (Absent)
            attendance, created = Attendance.objects.get_or_create(
                student=student,
                date=today,
                defaults={'status': status, 'class_teacher': teacher}
            )
            if not created:
                attendance.status = status
                attendance.save()

        messages.success(request, "Attendance has been recorded successfully.")
        return redirect('teachers_dashboard')

    attendance_exists = Attendance.objects.filter(student__in=students, date=today).exists()
    class_name = teacher.class_teacher_of_grade

    context = {
        'today': today,
        'class_name': class_name,
        'students': students,
        'attendance_exists': attendance_exists,
    }

    return render(request, 'teacher/add_attendance.html', context)

#from django.shortcuts import render
#from .models import Student, Attendance
#from datetime import date
#from django.utils.dateparse import parse_date

#def list_attendance(request):
#    class_teacher = request.user.teacher
#    students = Student.objects.filter(grade=class_teacher.class_teacher_of_grade, is_deleted=False).order_by('first_name')
#    
#    # Get the selected date from the request or default to today
#    selected_date = request.GET.get('attendance_date')
#    if selected_date:
#        selected_date = parse_date(selected_date)
#    else:
#        selected_date = date.today()

#    # Get attendance records for the selected date
#    attendance_records = {attendance.student.pk: attendance.status for attendance in Attendance.objects.filter(date=selected_date)}

#    context = {
#        'students': students,
#        'attendance_records': attendance_records,
#        'selected_date': selected_date,
#        'class_name': class_teacher.class_teacher_of_grade,
#    }

#    return render(request, 'teacher/list_attendance.html', context)





from django.shortcuts import render
from .models import Student, Attendance
from datetime import date
from django.utils.dateparse import parse_date

def list_attendance(request):
    class_teacher = request.user.teacher
    students = Student.objects.filter(grade=class_teacher.class_teacher_of_grade, is_deleted=False).order_by('first_name')
    
    # Get the selected date from the request or default to today
    selected_date = request.GET.get('attendance_date')
    if selected_date:
        selected_date = parse_date(selected_date)
    else:
        selected_date = date.today()
    
    # Get attendance records for the selected date
    attendance_records = Attendance.objects.filter(date=selected_date, student__in=students)
    
    # Create a dictionary to store attendance status for each student
    attendance_dict = {record.student_id: record.status for record in attendance_records}
    
    context = {
        'students': students,
        'attendance_dict': attendance_dict,
        'selected_date': selected_date,
        'class_name': class_teacher.class_teacher_of_grade,
    }
    
    return render(request, 'teacher/list_attendance.html', context)







def teacher_login(request):
    if request.method == 'POST':
        form = TeacherLogForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None and user.role == 'teacher':  # Ensure the user is a teacher
                login(request, user)
                return redirect('teachers_dashboard')
            else:
                form.add_error(None, 'Invalid username or password.')
    else:
        form = TeacherLogForm()
    return render(request, 'teacher/login.html', {'form': form})


@user_passes_test(is_teacher, login_url='teacher_login')
def teachers_dashboard(request):
    return render(request, 'teacher/dashboard.html')



def student_login(request):
    if request.method == 'POST':
        form = StudentLogForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('student_dashboard')
            else:
                form.add_error(None, 'Invalid username or password.')
    else:
        form = StudentLogForm()
    return render(request, 'student/login.html', {'form': form})










from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import user_passes_test
from .models import Grade
from .forms import GradeForm


@user_passes_test(is_principal, login_url='principal_login')
def list_grades(request):
    grades = Grade.objects.all()
    return render(request, 'principal/list_grades.html', {'grades': grades})

@user_passes_test(is_principal, login_url='principal_login')
def add_grade(request):
    if request.method == 'POST':
        form = GradeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('list_grades')
    else:
        form = GradeForm()
    return render(request, 'principal/add_grade.html', {'form': form})

@user_passes_test(is_principal, login_url='principal_login')
def delete_grade(request, grade_id):
    grade = get_object_or_404(Grade, id=grade_id)
    if request.method == 'POST':
        grade.delete()
        return redirect('list_grades')
    return render(request, 'principal/delete_grade.html', {'grade': grade})



















from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login
from django.db import IntegrityError


def check_aadhaar(request):
    if request.method == 'POST':
        form = AadhaarForm(request.POST)
        if form.is_valid():
            adhar_num = form.cleaned_data['adhar_num']
            try:
                student = Student.objects.get(adhar_num=adhar_num)
                return redirect('register_student', student_id=student.id)
            except Student.DoesNotExist:
                form.add_error('adhar_num', 'Aadhaar number not found.')
    else:
        form = AadhaarForm()
    return render(request, 'student/check_aadhaar.html', {'form': form})

# jjapp/views.py

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login
from django.db import IntegrityError

from .models import Student

def register_student(request, student_id):
    student = get_object_or_404(Student, id=student_id)
    if request.method == 'POST':
        user_form = CustomUserForm(request.POST)
        if user_form.is_valid():
            try:
                user = user_form.save(commit=False)
                user.role = 'student'
                user.set_password(user_form.cleaned_data['password'])
                user.save()
                student.user = user
                student.save()
                return redirect('login')
            except IntegrityError:
                user_form.add_error(None, 'A user with this username already exists.')
    else:
        user_form = CustomUserForm()
    return render(request, 'student/register_student.html', {'user_form': user_form, 'student': student})













def principal_login(request):
    if request.method == 'POST':
        form = PrincipalForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('principal_dashboard')

    else:
        form = PrincipalForm()
    return render(request, 'principal/login.html', {'form': form})






def login_student(request):
    if request.method == 'POST':
        form = StudentLogForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('student_dashboard')
            else:
                form.add_error(None, 'Invalid username or password.')
    else:
        form = StudentLogForm()
    return render(request, 'student/login.html', {'form': form})


@user_passes_test(is_student, login_url='login')
def student_dashboard(request):
    return render(request, 'student/dashboard.html')





from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required, user_passes_test
from django.utils import timezone
from .models import Complaint
from .forms import ComplaintForm, ComplaintResolutionForm

@login_required
def file_complaint(request):
    if request.method == 'POST':
        form = ComplaintForm(request.POST)
        if form.is_valid():
            complaint = form.save(commit=False)
            complaint.complainant = request.user
            complaint.complainant_role = request.user.role  # set the complainant role
            complaint.save()
            return redirect('complaint_list')
    else:
        form = ComplaintForm()
    return render(request, 'file_complaint.html', {'form': form})

@login_required
def complaint_list(request):
    complaints = Complaint.objects.all()
    return render(request, 'complaint_list.html', {'complaints': complaints})

@user_passes_test(is_principal, login_url='principal_login')
def resolve_complaint(request, complaint_id):
    complaint = Complaint.objects.get(id=complaint_id)
    if request.method == 'POST':
        form = ComplaintResolutionForm(request.POST, instance=complaint)
        if form.is_valid():
            if form.cleaned_data['is_resolved']:
                complaint.resolution_date = timezone.now()
            form.save()
            return redirect('complaint_list')
    else:
        form = ComplaintResolutionForm(instance=complaint)
    return render(request, 'resolve_complaint.html', {'form': form, 'complaint': complaint})









from django.shortcuts import render, redirect, get_object_or_404
from .models import Grade, Subject
from .forms import PrincipalSubjectForm

from django.shortcuts import render, redirect, get_object_or_404
from django.forms import ModelForm
from django.contrib.auth.decorators import user_passes_test
from .models import Classroom, Subject, Grade, Teacher, TeacherSubjectAssignment
from .forms import SubjectForm, TeacherSubjectForm

# Ensure only principals can access this view
#@user_passes_test(lambda user: user.is_authenticated and user.role == 'principal', login_url='principal_login')
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import user_passes_test
from .models import Classroom, Subject
#from .forms import ClassroomForm, SubjectForm

#@user_passes_test(lambda user: user.is_authenticated and user.role == 'principal', login_url='principal_login')

# jjapp/views.py
from django.shortcuts import render, redirect, get_object_or_404
from .models import Grade, Subject
from .forms import SubjectForm

from .models import Classroom

def add_grade_subjects(request, grade_id):
    grade = get_object_or_404(Grade, pk=grade_id)

    if request.method == 'POST':
        form = SubjectForm(request.POST)
        if form.is_valid():
            subject = form.save(commit=False)
            subject.grade = grade

            # Assuming you have a classroom associated with the grade
            classroom = Classroom.objects.filter(grade=grade).first()
            if classroom:
                subject.classroom = classroom
            else:
                # Handle the case where no classroom exists for the grade
                # You can either create a new classroom or handle the error differently
                pass

            subject.save()
            return redirect('grade_detail', grade_id=grade.id)
    else:
        form = SubjectForm()

    return render(request, 'add_grade_subjects.html', {'form': form, 'grade': grade})
#@user_passes_test(lambda user: user.is_authenticated and user.role == 'teacher', login_url='teacher_login')
from django.shortcuts import render, redirect
from .forms import TeacherSubjectAssignmentForm
from .models import TeacherSubjectAssignment
from django.shortcuts import render, redirect
from .forms import TeacherSubjectAssignmentForm
from .models import TeacherSubjectAssignment
from django.shortcuts import render, redirect
from .forms import TeacherSubjectAssignmentForm
from .models import TeacherSubjectAssignment

from django.shortcuts import render, redirect
from .forms import TeacherSubjectAssignmentForm
from django.contrib.auth.decorators import login_required

@login_required
def assign_subjects_view(request):
    try:
        teacher = request.user.teacher  # Assuming you have a OneToOne relationship from User to Teacher
    except AttributeError:
        # Handle case where the user is not a teacher
        return redirect('not_authorized')  # or another appropriate response

    if request.method == 'POST':
        form = TeacherSubjectAssignmentForm(request.POST)
        if form.is_valid():
            teacher_subject_assignment = form.save(commit=False)
            teacher_subject_assignment.teacher = teacher
            teacher_subject_assignment.save()
            return redirect('teacher_results_main')  # Replace with the appropriate success URL
    else:
        form = TeacherSubjectAssignmentForm()

    return render(request, 'assign_subjects.html', {'form': form})


from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect


# @login_required

# @login_required
def teacher_subjects(request):
    try:
        teacher = request.user.teacher
    except AttributeError:
        return redirect('not_authorized')  # Redirect to a not authorized page or some other appropriate action
    
    subjects = TeacherSubjectAssignment.objects.filter(teacher=teacher)
    return render(request, 'teacher_subjects.html', {'subjects': subjects})


def not_authorized(request):
    return render(request, 'not_authorized.html')




from django.shortcuts import render, get_object_or_404
from .models import Grade, Subject

def grade_detail(request, grade_id):
    grade = get_object_or_404(Grade, pk=grade_id)
    subjects = Subject.objects.filter(grade=grade)
    context = {
        'grade': grade,
        'subjects': subjects,
    }
    return render(request, 'grade_detail.html', context)







# jjapp/views.py

# jjapp/views.py

#from django.shortcuts import render, redirect
#from django.contrib.auth.decorators import login_required
#from .models import Student
#from .forms import StudentProfileUpdateForm

#@login_required
#def student_profile_pk(request):
#    student = objects.get(pk= request.pk)
#    if request.method == 'POST':
#        form = StudentProfileForm(instance=student)
#        return redirect('student_profile')
#    else:
#        form = StudentProfileForm(instance=student)
#    context = {
#        'student': student,
#        'form': form
#    }
#    return render(request, 'student/profile.html', context)
#    
#    
    
    
    
#    
#@login_required
#def student_profile(request):
#    try:
#        student = Student.objects.get(adhar_num=request.user.username)  # Assuming aadhaar_num is unique
#    except Student.DoesNotExist:
#        student = None

#    if request.method == 'POST':
#        form = StudentProfileForm(request.POST, instance=student)
#        if form.is_valid():
#            form.save()
#            return redirect('student_profile')
#    else:
#        form = StudentProfileForm(instance=student)
#    
#    context = {
#        'student': student,
#        'form': form
#    }
#    return render(request, 'student/profile.html', context)








# views.py
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from .models import Student
from .forms import ProfilePhotoForm

@login_required
@user_passes_test(is_student, login_url='login')
def student_profilek(request):
    try:
        student = Student.objects.get(adhar_num=request.user.username)
        print('good')  # Assuming aadhaar_num is unique
    except Student.DoesNotExist:
        student = None    
    
#    student = get_object_or_404(Student, id=student_id)
    
    if request.method == 'POST':
        form = ProfilePhotoForm(request.POST, request.FILES, instance=student)
        if form.is_valid():
            form.save()
            return JsonResponse({'success': True, 'photo_url': student.profile_photo.url})
        else:
            return JsonResponse({'success': False, 'errors': form.errors})
    
    context = {
        'student': student,
        'form': ProfilePhotoForm(),
    }
    print(student)
    return render(request, '5.html', context)


#    
    
    
    
    
    
    
    
    
    
    

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from .models import Teacher, TeacherSubjectAssignment, Grade, Subject, Student, Result, Exam
from .forms import ResultForm



@user_passes_test(is_teacher, login_url='teacher_login')
def exam_list(request):
    exams = Exam.objects.all()
    return render(request, 'exam_list.html', {'exams': exams})

@login_required 
@user_passes_test(is_teacher)
def teacher_classes(request, exam_id):
    teacher = request.user.teacher
    assignments = TeacherSubjectAssignment.objects.filter(teacher=teacher)
    exam = get_object_or_404(Exam, id=exam_id)
    return render(request, 'teacher_classes.html', {'assignments': assignments, 'exam': exam})

@login_required
@user_passes_test(is_teacher)
def class_students(request, exam_id, assignment_id):
    assignment = get_object_or_404(TeacherSubjectAssignment, id=assignment_id, teacher=request.user.teacher)
    exam = get_object_or_404(Exam, id=exam_id)
    students = Student.objects.filter(grade=assignment.grade)
    return render(request, 'class_students.html', {
        'assignment': assignment,
        'exam': exam,
        'students': students
    })

@login_required
@user_passes_test(is_teacher)
def add_edit_result(request, exam_id, assignment_id, student_id):
    assignment = get_object_or_404(TeacherSubjectAssignment, id=assignment_id, teacher=request.user.teacher)
    exam = get_object_or_404(Exam, id=exam_id)
    student = get_object_or_404(Student, id=student_id, grade=assignment.grade)
    result, created = Result.objects.get_or_create(
        student=student,
        exam=exam,
        subject=assignment.subject
    )

    if request.method == 'POST':
        form = ResultForm(request.POST, instance=result)
        if form.is_valid():
            form.save()
            messages.success(request, 'Result saved successfully.')
            return redirect('class_students', exam_id=exam_id, assignment_id=assignment_id)
    else:
        form = ResultForm(instance=result)

    return render(request, 'add_edit_result.html', {
        'form': form,
        'assignment': assignment,
        'exam': exam,
        'student': student,
    })
    
    
    
    
    
    
    
    
    
    
    
    


@login_required
def student_exam_list(request):
    student = get_object_or_404(Student, adhar_num=request.user.username)
    exams = Exam.objects.all()
    return render(request, 'student/exam_list.html', {'exams': exams})

@login_required
def student_exam_results(request, exam_id):
    student = get_object_or_404(Student, adhar_num=request.user.username)
    exam = get_object_or_404(Exam, id=exam_id)
    results = Result.objects.filter(student=student, exam=exam)
    return render(request, 'student/exam_results.html', {'exam': exam, 'results': results})

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import user_passes_test
from django.db.models import Q
from django.contrib import messages
from .models import Student
from .forms import FeePaymentForm

def is_principal(user):
    return user.is_authenticated and user.role == 'principal'

#@user_passes_test(is_principal)
def student_fee_list(request):
    query = request.GET.get('query', '')
    if query:
        students = Student.objects.filter(
            Q(first_name__icontains=query) |
            Q(last_name__icontains=query) |
            Q(roll_number__icontains=query)
        )
    else:
        students = Student.objects.all()

    return render(request, 'student_fee_list.html', {'students': students, 'query': query})

#vg@user_passes_test(is_principal)
def student_fee_detail(request, student_id):
    student = get_object_or_404(Student, pk=student_id)
    if request.method == 'POST':
        form = FeePaymentForm(request.POST)
        if form.is_valid():
            amount_paid = form.cleaned_data['amount_paid']
            student.update_fees(amount_paid)
            
            if amount_paid > student.remaining_fee:
                overpayment = amount_paid - student.remaining_fee
                messages.success(request, f"Fee payment of {student.remaining_fee} successfully recorded for {student.first_name} {student.last_name}. Overpayment of {overpayment} added to advanced payment.")
            else:
                messages.success(request, f"Fee payment of {amount_paid} successfully recorded for {student.first_name} {student.last_name}")
            
            return redirect('student_fee_detail', student_id=student.pk)
    else:
        form = FeePaymentForm()

    return render(request, 'student_fee_detail.html', {'student': student, 'form': form})    
    
    
    
    
    
    
    
    
    
    
    
    
    
from django.shortcuts import render, get_object_or_404
from .models import Classroom, Teacher, Student, Subject
from django.db.models import Count, Avg
from django.utils import timezone

from django.shortcuts import render
from .models import Classroom, Teacher
from django.db.models import Count, Avg
from django.utils import timezone

from django.shortcuts import render
from django.contrib.auth.decorators import user_passes_test
from django.db.models import Count, Avg, F, Subquery, OuterRef
from django.db.models.functions import Coalesce
from django.utils import timezone
from datetime import timedelta
from .models import Classroom, Grade, Attendance

def is_principal(user):
    return user.is_authenticated and user.role == 'principal'

@user_passes_test(is_principal, login_url='principal_login')
def classroom_list(request):
    # Subquery to get student count by grade
    grade_student_count = Grade.objects.filter(id=OuterRef('grade_id')).annotate(
        count=Count('students')
    ).values('count')

    # Subquery to get average attendance for the last 30 days
    thirty_days_ago = timezone.now().date() - timedelta(days=30)
    attendance_subquery = Attendance.objects.filter(
        student__classroom=OuterRef('pk'),
        date__gte=thirty_days_ago
    ).values('student__classroom').annotate(
        avg_attendance=Avg('status')
    ).values('avg_attendance')

    classrooms = Classroom.objects.select_related('grade', 'class_teacher__user').annotate(
        student_count=Count('students'),
        grade_student_count=Coalesce(Subquery(grade_student_count), 0),
        attendance_percentage=Coalesce(Subquery(attendance_subquery), 0) * 100
    ).order_by('grade__level', 'name')

    context = {
        'classrooms': classrooms,
    }
    return render(request, '1.html', context)
    

    
    
    
    
    
    
    
    
    
    
def classroom_detail(request, pk):
    classroom = get_object_or_404(Classroom, pk=pk)
    total_students = classroom.students.count()
    attendance_percentage = classroom.attendance_percentage()
    class_teacher = Teacher.objects.filter(class_teacher_of_grade=classroom.grade).first()
    students = Student.objects.filter(classroom=classroom)
    subjects = Subject.objects.filter(classroom=classroom)

    context = {
        'classroom': classroom,
        'total_students': total_students,
        'attendance_percentage': attendance_percentage,
        'class_teacher': class_teacher,
        'students': students,
        'subjects': subjects
    }
    return render(request, 'classroom_detail.html', context)
    
    
    
    
    
    
    
    
    
from django.views.generic import ListView, DetailView
from django.db.models import Avg
from .models import Classroom, Teacher, Attendance
from django.utils import timezone
from django.views.generic import ListView
from django.db.models import Count, Avg, OuterRef, Subquery
from .models import Classroom, Teacher, Grade

from django.views.generic import ListView
from django.db.models import Count, Avg, OuterRef, Subquery
from .models import Classroom, Teacher, Grade

from django.views.generic import ListView
from django.db.models import Count, Avg, OuterRef, Subquery
from .models import Classroom, Teacher, Grade













from django.views.generic import ListView
from django.db.models import Count, Avg
from .models import Classroom, Grade, Teacher, Student
from django.views.generic import ListView
from django.db.models import Count, Avg
from .models import Classroom, Grade, Teacher, Student

class ClassroomListView(ListView):
    model = Classroom
    template_name = 'classroom_list.html'
    context_object_name = 'classrooms'

    def get_queryset(self):
        return Classroom.objects.select_related('grade')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Get all grades
        grades = Grade.objects.all()
        
        # Get class teachers for each grade
        class_teachers = {}
        for grade in grades:
            teacher = Teacher.objects.filter(class_teacher_of_grade=grade).first()
            if teacher:
                class_teachers[grade.id] = f"{teacher.user.first_name} {teacher.user.last_name}"
            else:
                class_teachers[grade.id] = "Not Assigned"
        
        # Get student count for each grade
        grade_student_counts = Student.objects.values('grade').annotate(count=Count('id'))
        grade_student_counts_dict = {item['grade']: item['count'] for item in grade_student_counts}
        
        # Add student count to each grade
        for grade in grades:
            grade.student_count = grade_student_counts_dict.get(grade.id, 0)
        
        # Get student count and attendance percentage for each classroom based on grade
        classroom_data = {}
        for classroom in context['classrooms']:
            students = Student.objects.filter(grade=classroom.grade)
            student_count = students.count()
            
            # Calculate attendance percentage
            attendance_sum = sum(student.attendances.filter(status=1).count() for student in students)
            total_attendances = sum(student.attendances.count() for student in students)
            attendance_percentage = (attendance_sum / total_attendances * 100) if total_attendances > 0 else 0
            
            classroom_data[classroom.id] = {
                'student_count': student_count,
                'attendance_percentage': attendance_percentage
            }
        
        # Get class teachers for each classroom
        classroom_teachers = {}
        for classroom in context['classrooms']:
            teacher = Teacher.objects.filter(class_teacher_of_grade=classroom.grade).first()
            if teacher:
                classroom_teachers[classroom.id] = f"{teacher.user.username}"
            else:
                classroom_teachers[classroom.id] = "Not Assigned"
        
        context['grades'] = grades
        context['class_teachers'] = class_teachers
        context['classroom_teachers'] = classroom_teachers
        context['classroom_data'] = classroom_data
        return context
        
        
        
        
        
        
        
        
        
        
from django.views.generic import DetailView
from django.db.models import Avg, Count
from .models import Classroom, Teacher, Student, Subject, Attendance

from django.views.generic import DetailView
from django.db.models import Count, Avg
from .models import Classroom, Teacher, Student, Subject, Attendance

class ClassroomDetailView(DetailView):
    model = Classroom
    template_name = 'classroom_detail.html'
    context_object_name = 'classroom'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        classroom = self.object

        # Get students for this grade
        students = Student.objects.filter(grade=classroom.grade).select_related('grade')
        
        # Calculate total students
        context['total_students'] = students.count()

        # Basic classroom info
        context['attendance_percentage'] = classroom.attendance_percentage()
        context['class_teacher'] = Teacher.objects.filter(class_teacher_of_grade=classroom.grade).first()

        # All students in the grade
        context['students'] = students.order_by('roll_number')

        # Subject and teacher information
        subjects = Subject.objects.filter(grade=classroom.grade)
        subject_teachers = []
        for subject in subjects:
            teacher = Teacher.objects.filter(teachersubjectassignment__subject=subject, teachersubjectassignment__grade=classroom.grade).first()
            subject_teachers.append({
                'subject': subject,
                'teacher': teacher
            })
        context['subject_teachers'] = subject_teachers

        # Student performance summary
        performance_summary = students.aggregate(
            avg_performance=Avg('performance'),
            top_performers_count=Count('id', filter=models.Q(performance__gte=80))
        )
        context['avg_performance'] = performance_summary['avg_performance']
        context['top_performers_count'] = performance_summary['top_performers_count']

        # Recent attendance summary
        recent_attendance = Attendance.objects.filter(student__in=students).order_by('-date')[:30]
        attendance_summary = recent_attendance.aggregate(
            present_count=Count('id', filter=models.Q(status=1)),
            total_count=Count('id')
        )
        context['recent_attendance_percentage'] = (attendance_summary['present_count'] / attendance_summary['total_count']) * 100 if attendance_summary['total_count'] > 0 else 0

        return context
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
class ClassroomTeacherView(DetailView):
    model = Classroom
    template_name = 'classroom_list_teacher.html'
    context_object_name = 'classroom'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        classroom = self.object
        
        
        subjects = Subject.objects.filter(grade=classroom.grade)
        subject_teachers = []
        for subject in subjects:
            teacher = Teacher.objects.filter(teachersubjectassignment__subject=subject, teachersubjectassignment__grade=classroom.grade).first()
            subject_teachers.append({
                'subject': subject,
                'teacher': teacher
            })
        context['subject_teachers'] = subject_teachers
        
        return context 

        
        
        
        
        
        
        
        
        
        
        
from django.views.generic import DetailView
from django.shortcuts import get_object_or_404
from .models import Classroom, Subject, TeacherSubjectAssignment

class ClassroomAssignmentsView(DetailView):
    model = Classroom
    template_name = 'classroom_assignments.html'
    context_object_name = 'classroom'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        classroom = self.object
        subjects = Subject.objects.filter(grade=classroom.grade)
        
        assigned_teachers = []
        for subject in subjects:
            assignment = TeacherSubjectAssignment.objects.filter(
                subject=subject, 
                grade=classroom.grade
            ).select_related('teacher__user').first()
            
            assigned_teachers.append({
                'subject': subject,
                'teacher': assignment.teacher if assignment else None
            })
        
        context['assigned_teachers'] = assigned_teachers
        return context        
        
        
        
        
        
        
        
        
@login_required
def teacher_subjects(request):
    try:
        teacher = request.user.teacher
    except Teacher.DoesNotExist:
        return redirect('not_authorized')
    
    subjects = TeacherSubjectAssignment.objects.filter(teacher=teacher)
    can_add_more = subjects.count() < 5
    
    return render(request, 'teacher_subjects.html', {
        'assignment': subjects,
        'can_add_more': can_add_more
    })


def add_subject(request):
    try:
        teacher = request.user.teacher
    except Teacher.DoesNotExist:
        return redirect('not_authorized')
    
    if request.method == 'POST':
        form = TeacherSubjectAssignmentForm(request.POST, teacher=teacher)
        if form.is_valid():
            assignment = form.save(commit=False)
            assignment.teacher = teacher
            try:
                assignment.save()
                messages.success(request, "Subject assigned successfully.")
                return redirect('teacher_subjects')
            except IntegrityError:
                messages.error(request, "You've already assigned this subject for this grade.")
    else:
        form = TeacherSubjectAssignmentForm(teacher=teacher)
    
    return render(request, 'add_subject.html', {'form': form})

def load_subjects(request):
    grade_id = request.GET.get('grade')
    subjects = Subject.objects.filter(grade_id=grade_id).order_by('name')
    return render(request, 'subject_dropdown_list_options.html', {'subjects': subjects})

@login_required
def remove_subject(request, assignment_id):
    assignment = get_object_or_404(TeacherSubjectAssignment, id=assignment_id, teacher=request.user.teacher)
    assignment.delete()
    messages.success(request, "Subject removed successfully.")
    return redirect('teacher_subjects')
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
# views.py
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from .models import Attendance, Coordinates
from django.views.decorators.csrf import csrf_exempt
from django.utils import timezone
# views.py
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from .models import Attendance, Coordinates
from django.views.decorators.csrf import csrf_exempt
from django.utils import timezone

@login_required
@csrf_exempt
def mark_attendance(request):
    if request.method == 'POST':
        latitude = float(request.POST.get('latitude'))
        longitude = float(request.POST.get('longitude'))
        
        # Check if attendance has already been marked today
        today = timezone.now().date()
        existing_attendance = AttendanceT.objects.filter(user=request.user, date=today).first()
        
        if existing_attendance:
            return JsonResponse({
                'status': 'error', 
                'message': 'You have already marked your attendance for today.'
            })
        
        # Check if the coordinates are within the boundary
        school_coordinates = Coordinates.objects.first()  # Assuming you have only one set of coordinates
        if school_coordinates and school_coordinates.is_within_boundary(latitude, longitude):
            AttendanceT.objects.create(
                user=request.user,
                status=1,  # Present
                latitude=latitude,
                longitude=longitude
            )
            return JsonResponse({
                'status': 'success', 
                'message': 'Your attendance has been marked successfully for today.'
            })
        else:
            return JsonResponse({
                'status': 'error', 
                'message': 'You are not within the allowed radius. Attendance not marked.'
            })
    
    return render(request, 'mark_attendance.html')

# models.py and template remain the same as in the previous example












#def user_io(request):
# 
#    context = {
#        'summary_titles': ['Total Users', 'Revenue', 'Orders', 'Growth'],
#        'recent_activities': ['User signup', 'New order placed', 'Payment received'],
#        'quick_actions': ['Create invoice', 'Add product', 'View reports'],
#    }


#     return render(request, '2.html', context)



from django.contrib.auth.decorators import login_required
from django.utils import timezone
from datetime import timedelta
from .models import Student, Subject, Attendance, Grade, Classroom, Teacher


from django.shortcuts import render

def user_io(request):

    print("Entering teacher_dashboard view")

    try:
        teacher = Teacher.objects.get(user=request.user)
        print(f"Teacher: {teacher}")
    except Teacher.DoesNotExist:
        return HttpResponse("Teacher not found for this user")
   

    # Get total students
    total_students = Student.objects.filter(grade =teacher.class_teacher_of_grade).count()
    print(f"Total students: {total_students}")

    # Get active subjects
    active_subjects = TeacherSubjectAssignment.objects.filter(teacher=teacher).count()
    print(f"Active subjects: {active_subjects}")

    # Calculate average attendance for the last 30 days
    thirty_days_ago = timezone.now().date() - timedelta(days=30)
    avg_attendance = Attendance.objects.filter(
        class_teacher=teacher,
        date__gte=thirty_days_ago
    ).aggregate(avg_status=Avg('status'))['avg_status']

    if avg_attendance is not None:
        avg_attendance = avg_attendance * 125
    else:
        avg_attendance = 0
    print(f"Average attendance: {avg_attendance}%")
    
    
    
    thir_days_ago = timezone.now().date() - timedelta(days=7)
#    avg_attendance = Attendance.objects.filter(
#        class_teacher=teacher,
#        date__gte=thirty_days_ago
#    ).aggregate(avg_status=Avg('status'))['avg_status']


    # Get attendance data for chart
    attendance_data = Attendance.objects.filter(
        class_teacher=teacher,
        date__gte=thir_days_ago
    ).values('date').annotate(
        attendance_percentage=Avg('status') * 100,
        total_students=Count('student', distinct=True)
    ).order_by('date')

    attendance_dates = []
    attendance_percentages = []
    for data in attendance_data:
        attendance_dates.append(data['date'].strftime('%Y-%m-%d'))
        attendance_percentages.append(data['attendance_percentage'] or 0)
        print(f"Date: {data['date']}, Percentage: {data['attendance_percentage']}, Students: {data['total_students']}")

    # Get recent activities (this is a placeholder)
    recent_activities = [
        {'description': 'Graded Math 101 assignments', 'timestamp': timezone.now() - timedelta(hours=2)},
        {'description': 'Updated Science course syllabus', 'timestamp': timezone.now() - timedelta(hours=4)},
        {'description': 'Scheduled parent-teacher meeting', 'timestamp': timezone.now() - timedelta(days=1)},
        {'description': 'Posted new announcement for English class', 'timestamp': timezone.now() - timedelta(days=1, hours=12)},
    ]
    
    
    
    students = Student.objects.filter(grade =teacher.class_teacher_of_grade).select_related('grade')

    context = {
        'teacher': teacher,
        'total_students': total_students,
        'active_subjects': active_subjects,
        'avg_attendance': avg_attendance,
        'attendance_dates': attendance_dates,
        'attendance_percentages': attendance_percentages,
        'recent_activities': recent_activities,
         'students': students,
    }

    print("Context prepared, rendering template")

    return render(request, '3.html', context)




def user(request):

    
    return render(request , "6.html")

  # views.py
from django.views.generic import ListView
from django.db.models import Q
from .models import Student
from django.views.generic import ListView, TemplateView
from django.db.models import Count, Avg, Sum, F, ExpressionWrapper, FloatField
from django.db.models.functions import Coalesce
from django.utils import timezone
from .models import Student, Teacher, Classroom, Attendance, Event, Complaint, Chapter
from django.contrib.humanize.templatetags.humanize import intcomma
from decimal import Decimal
from django.views.generic import ListView
from django.db.models import Q
from django.template.loader import render_to_string
from django.http import JsonResponse

class StudentListView(ListView):
    model = Student
    template_name = '4.html'
    context_object_name = 'students'
    paginate_by = 10
    

    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        top_students = Student.objects.annotate(
        total_marks=Sum('results__marks_obtained')
    ).order_by('-total_marks')[:3]
        context["top_students"] = top_students

        
        # Student statistics
        context['total_students'] = Student.objects.filter(is_deleted=False).count()
        
        
        
        context['teacher'] =Teacher.objects.all()
        
        
        pra = Attendance.objects.filter(
            date__gte=timezone.now() - timezone.timedelta(days=30)
        ).aggregate(avg_attendance=Avg('status'))['avg_attendance'] or 0
        pra *= 100
        context['avg_attendance'] = round(pra, 2) # Convert to percentage
        
        # Teacher statistics
        context['total_teachers'] = Teacher.objects.count()
        
        # Financial statistics
        total_fee = Student.objects.aggregate(total=Sum('total_fee'))['total'] or 0
        remaining_fee = Student.objects.aggregate(remaining=Sum('remaining_fee'))['remaining'] or 0
        context['fee_collection_rate'] = ((total_fee - remaining_fee) / total_fee) * 100 if total_fee > 0 else 0
        
        fee = f"₹{intcomma('{:.2f}'.format( int( remaining_fee)))}"
    
        
        context['fee'] = fee
        
 
        
        
        # Classroom statistics
       # context['classroom_occupancy'] = self.get_classroom_occupancy()
        
        # Recent events
        context['upcoming_events'] = Event.objects.filter(date__gte=timezone.now().date()).order_by('date')[:5]
        
        # Complaints statistics
        context['open_complaints'] = Complaint.objects.filter(is_resolved=False).count()
        
        # Academic progress
        #context['subject_progress'] = self.get_subject_progress()
        
        # Performance data for chart
        #context['performance_data'] = self.get_performance_data()
        
        # Recent activities
       # context['recent_activities'] = self.get_recent_activities()
        
        return context
        
        
        
        
        
    def get_classroom_occupancy(self):
        classrooms = Classroom.objects.annotate(
            occupancy_rate=ExpressionWrapper(
                F('total_students') * 100.0 / F('capacity'),
                output_field=FloatField()
            )
        )
        return classrooms.aggregate(avg_occupancy=Avg('occupancy_rate'))['avg_occupancy'] or 0

    def get_subject_progress(self):
        return Chapter.objects.annotate(
            completion=Avg('tasks__is_completed')
        ).values('subject__name').annotate(
            avg_completion=Avg('completion') * 100
        ).order_by('-avg_completion')[:5]

    def get_performance_data(self):
        # This is a placeholder. In a real application, you'd query your database for actual performance data
        return [75, 78, 80, 79, 82, 85, 87, 88, 86, 89, 90, 92]

    def get_recent_activities(self):
        # This is a placeholder. In a real application, you'd query your database for actual recent activities
        return [
            {"type": "new_student", "description": "New student enrolled: John Doe", "time": "2 hours ago"},
            {"type": "event", "description": "Upcoming event: Annual Sports Day", "time": "1 day ago"},
            {"type": "complaint", "description": "New complaint filed: Facility Issue", "time": "2 days ago"},
        ]

    def get_queryset(self):
        queryset = Student.objects.filter(is_deleted=False).select_related('grade')
        query = self.request.GET.get('q')
        if query:
            queryset = queryset.filter(
                Q(first_name__icontains=query) |
                Q(last_name__icontains=query) |
                Q(roll_number__icontains=query) |
                Q(grade__name__icontains=query)
            )
        return queryset

    def render_to_response(self, context, **response_kwargs):
        if self.request.headers.get('x-requested-with') == 'XMLHttpRequest':
            html = render_to_string(
                'students_table_partial.html',
                context,
                request=self.request
            )
            return JsonResponse({'html': html})
        return super().render_to_response(context, **response_kwargs)


from django.views.generic import ListView, DetailView, CreateView, UpdateView
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.shortcuts import get_object_or_404
from django.urls import reverse_lazy
from django.http import JsonResponse
from django.utils import timezone
from .models import Grade, Subject, Chapter, Task

class TeacherRequiredMixin(UserPassesTestMixin):
    def test_func(self):
        return self.request.user.is_authenticated and self.request.user.role == 'teacher'

class TeacherGradeListView(LoginRequiredMixin, TeacherRequiredMixin, ListView ):
    model = Grade
    template_name = 'teacher/grade_list.html'
    context_object_name = 'grades'

    def get_queryset(self):
        grade = TeacherSubjectAssignment.objects.filter(teacher=self.request.user.teacher)
  
        return grade

class TeacherSubjectListView(LoginRequiredMixin, TeacherRequiredMixin, ListView):
    model = Subject
    template_name = 'teacher/subject_list.html'
    context_object_name = 'subjects'

    def get_queryset(self):
        grade = get_object_or_404(Grade, pk=self.kwargs['grade_id'])
        return TeacherSubjectAssignment.objects.filter(grade=grade , teacher= self.request.user.teacher)

class ChapterCreateView(LoginRequiredMixin, TeacherRequiredMixin, CreateView):
    model = Chapter
    fields = ['name', 'page_number']
    template_name = 'teacher/chapter_form.html'

    def form_valid(self, form):
        form.instance.subject = get_object_or_404(Subject, pk=self.kwargs['subject_id'])
        response = super().form_valid(form)
        return JsonResponse({
            'success': True,
            'id': self.object.id,
            'name': self.object.name,
            'page_number': self.object.page_number,
            'completion_percentage': self.object.completion_percentage,
        })

    def get_success_url(self):
        return reverse_lazy('teacher_subject_detail', kwargs={'pk': self.kwargs['subject_id']})

class ChapterListView(LoginRequiredMixin, TeacherRequiredMixin, ListView):
    model = Chapter
    template_name = 'teacher/chapter_list.html'
    context_object_name = 'chapters'

    def get_queryset(self):
        self.subject = get_object_or_404(Subject, pk=self.kwargs['subject_id'])
        return Chapter.objects.filter(subject=self.subject)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['subject'] = self.subject
        return context

class ChapterDetailView(LoginRequiredMixin, TeacherRequiredMixin, DetailView):
    model = Chapter
    template_name = 'teacher/chapter_detail.html'
    context_object_name = 'chapter'

class TaskCreateView(LoginRequiredMixin, TeacherRequiredMixin, CreateView):
    model = Task
    fields = ['title', 'description', 'completion_date']
    template_name = 'teacher/task_form.html'

    def form_valid(self, form):
        form.instance.chapter = get_object_or_404(Chapter, pk=self.kwargs['chapter_id'])
        form.instance.date_added = timezone.now()
        return super().form_valid(form)

    def get_success_url(self):
        return reverse_lazy('chapter_detail', kwargs={'pk': self.kwargs['chapter_id']})

class TaskUpdateView(LoginRequiredMixin, TeacherRequiredMixin, UpdateView):
    model = Task
    fields = ['is_completed']
    template_name = 'teacher/task_update_form.html'

    def form_valid(self, form):
        response = super().form_valid(form)
        return JsonResponse({'success': True})

    def get_success_url(self):
        return reverse_lazy('chapter_detail', kwargs={'pk': self.object.chapter.id})
        
        
        
        
from django.shortcuts import render, get_object_or_404
from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.db.models import Avg
from .models import Subject, Chapter, Task
from .forms import ChapterForm, TaskForm

def chapter_list(request, subject_id):
    subject = get_object_or_404(Subject, id=subject_id)
    chapters = Chapter.objects.filter(subject=subject).prefetch_related('tasks')
    chapter_form = ChapterForm()
    task_form = TaskForm()
    
    context = {
        'subject': subject,
        'chapters': chapters,
        'chapter_form': chapter_form,
        'task_form': task_form,
    }
    return render(request, 'teacher/chapter_list.html', context)

from django.http import JsonResponse
from django.core.serializers.json import DjangoJSONEncoder
from django.http import JsonResponse
from django.core.serializers.json import DjangoJSONEncoder
from django.shortcuts import get_object_or_404
from .models import Subject
from .forms import ChapterForm

def add_chapter(request, subject_id):
    subject = get_object_or_404(Subject, id=subject_id)
    if request.method == 'POST':
        form = ChapterForm(request.POST, subject=subject)
        if form.is_valid():
            chapter = form.save()
            return JsonResponse({'success': True})
        else:
            errors = {field: str(error) for field, error in form.errors.items()}
            return JsonResponse({'success': False, 'error': errors}, encoder=DjangoJSONEncoder)
    return JsonResponse({'success': False, 'error': 'Invalid request method'})

@require_POST
def add_task(request):
    form = TaskForm(request.POST)
    if form.is_valid():
        task = form.save(commit=False)
        task.chapter_id = request.POST.get('chapter_id')
        task.save()
        return JsonResponse({'success': True})
        print(task)
    return JsonResponse({'success': False, 'errors': form.errors})

@require_POST
def update_task(request):
    task_id = request.POST.get('task_id')
    is_completed = request.POST.get('is_completed') == 'true'
    task = get_object_or_404(Task, id=task_id)
    task.is_completed = is_completed
    task.save()
    
    # Calculate new completion percentage
    chapter = task.chapter
    completion_percentage = chapter.tasks.filter(is_completed=True).count() / chapter.tasks.count() * 100
    
    return JsonResponse({
        'success': True,
        'completion_percentage': completion_percentage
    })