// your_app_name/static/react_app/main.js

console.log("React.js is working!");

// Example React component
function App() {
    return (
        <div>
            <h1>Hello, React!</h1>
            <p>This is a simple React component rendered in Django.</p>
        </div>
    );
}

// Render the React component
ReactDOM.render(<App />, document.getElementById('root'));