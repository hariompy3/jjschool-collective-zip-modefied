from django.db import models
from django.utils import timezone
from django.contrib.auth.models import AbstractUser
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.conf import settings

class CustomUser(AbstractUser):
    ROLE_CHOICES = (
        ('student', 'Student'),
        ('teacher', 'Teacher'),
        ('principal', 'Principal'),
    )
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='student')
    email = models.EmailField(blank=True)  # Allow email to be blank
    REQUIRED_FIELDS = []

class Grade(models.Model):
    name = models.CharField(max_length=10)
    level = models.IntegerField()
    description = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.name} (Level {self.level})"

class Subject(models.Model):
    name = models.CharField(max_length=255)
    grade = models.ForeignKey(Grade, on_delete=models.CASCADE)
    classroom = models.ForeignKey('Classroom', related_name='subjects', on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return f"{self.name} - {self.grade.name}"
        
     #   from django.db import models
from django.utils import timezone
from django.db.models import Count

class Classroom(models.Model):
    #name = models.CharField(max_length=100)
    name = models.CharField(max_length=100, default="Unnamed Classroom")
    grade = models.ForeignKey(Grade, on_delete=models.CASCADE, related_name='classrooms')
    capacity = models.IntegerField()
    class_teacher = models.ForeignKey('Teacher', on_delete=models.SET_NULL, null=True, blank=True, related_name='class_teacher_of')
    teachers = models.ManyToManyField('Teacher', related_name='teaching_classes', blank=True)
    students = models.ManyToManyField('Student', related_name='enrolled_classrooms')
  #  total_students = models.IntegerField()

    def __str__(self):
        return f"{self.grade.name} - {self.name}"

    @property
    def total_students(self):
        return self.students.count()

    def attendance_percentage(self):
        thirty_days_ago = timezone.now().date() - timezone.timedelta(days=30)
        avg_status = Attendance.objects.filter(
            student__classroom=self,
            date__gte=thirty_days_ago
        ).aggregate(models.Avg('status'))['status__avg']
        
        return (avg_status or 0) * 100  # Return 0 if avg_status is None

    class Meta:
        ordering = ['grade__level', 'name']
        
        
    
# Automatically create a Classroom when a Grade is created
from django.db.models.signals import post_save
from django.dispatch import receiver

@receiver(post_save, sender=Grade)
def create_classroom(sender, instance, created, **kwargs):
    if created:
        Classroom.objects.create(
            grade=instance,
            capacity=40,
            name=f"{instance.name} Classroom"  # Use Grade name to create a default Classroom name
        )
        
        
        
        
class Student(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    date_of_birth = models.DateField()
    adhar_num = models.CharField(max_length=12, unique=True)
    admission_date = models.DateField()
    grade = models.ForeignKey(Grade, on_delete=models.CASCADE, related_name='students')
    classroom = models.ForeignKey(Classroom, on_delete=models.SET_NULL, null=True, blank=True, related_name='assigned_students')
    #classroom = models.ForeignKey(Classroom, on_delete=models.SET_NULL, null=True, blank=True, related_name='students')
    performance = models.TextField(blank=True)
    attendance_records = models.TextField(blank=True)
    disciplinary_actions = models.TextField(blank=True)
    total_fee = models.DecimalField(max_digits=10, decimal_places=2)
    remaining_fee = models.DecimalField(max_digits=10, decimal_places=2)
    attendance_percentage = models.FloatField(blank=True, null=True)
    is_deleted = models.BooleanField(default=False)
    roll_number = models.CharField(max_length=20, unique=True, blank=True, null=True)

    profile_photo = models.ImageField(upload_to='profile_photos/', blank=True, null=True)
    initial_setup_complete = models.BooleanField(default=False)
    advanced_payment = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    def update_fees(self, amount_paid):
        if amount_paid > self.remaining_fee:
            overpayment = amount_paid - self.remaining_fee
            self.advanced_payment += overpayment
            self.remaining_fee = 0
        else:
            self.remaining_fee -= amount_paid
        
        self.save()

    def get_actual_remaining_fee(self):
        return max(self.remaining_fee - self.advanced_payment, 0)
        
        
        
        
        
        
        
        
        

    def save(self, *args, **kwargs):
        if not self.roll_number:
            last_student = Student.objects.filter(grade=self.grade).order_by('-roll_number').first()
            if last_student and last_student.roll_number:
                next_roll_number = int(last_student.roll_number[-2:]) + 1
            else:
                next_roll_number = 1
            self.roll_number = f"{self.grade.level:02d}{str(next_roll_number).zfill(2)}"
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.first_name} {self.last_name} ({self.roll_number})"

class Teacher(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, primary_key=True)
    address = models.TextField()
    phone_number = models.CharField(max_length=15)
    date_of_birth = models.DateField()
    class_teacher_of_grade =models.ForeignKey(Grade, null=True, blank=True, on_delete=models.SET_NULL)
    main_subject = models.CharField(max_length=100)  # New field
    extra_subjects = models.CharField(max_length=200, blank=True, null=True)

    def __str__(self):
        return  self.user.username

class Principal(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, primary_key=True)
    phone_number = models.CharField(max_length=15, blank=True, null=True)

    def __str__(self):
        return self.user.get_full_name()

class Notification(models.Model):
    title = models.CharField(max_length=100)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class Attendance(models.Model):
    ATTENDANCE_STATUS = [
        (0, 'Absent'),
        (1, 'Present'),
    ]
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='attendances')
    class_teacher = models.ForeignKey(Teacher, on_delete=models.SET_NULL, null=True, blank=True, related_name='class_attendances')
    date = models.DateField(default=timezone.now)
    status = models.IntegerField(choices=ATTENDANCE_STATUS)
    recorded_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if not self.class_teacher:
            self.class_teacher = Teacher.objects.filter(class_teacher_of_grade=self.student.grade).first()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.student} - {self.date} - {self.get_status_display()}"

class Event(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True, null=True)
    date = models.DateField()
    time = models.TimeField()
    venue = models.CharField(max_length=200)
    organizer = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='events')
    event_type = models.CharField(max_length=100)

    def __str__(self):
        return self.title

class Exam(models.Model):
    name = models.CharField(max_length=200)
    #subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name='exams')
    date = models.DateField()
    duration = models.DurationField()

    def __str__(self):
        return self.name

class Result(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='results')
    exam = models.ForeignKey(Exam, on_delete=models.CASCADE, related_name='results')
    marks_obtained = models.FloatField(default=0)
    grade = models.CharField(max_length=2)
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    comments = models.TextField(default=0)  

    def __str__(self):
        return f"{self.student} - {self.exam} - {self.marks_obtained}"

class Homework(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True, null=True)
    assigned_date = models.DateField(default=timezone.now)
    due_date = models.DateField()
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name='homeworks')
    assigned_by = models.ForeignKey(Teacher, on_delete=models.CASCADE, related_name='homeworks')
    grade = models.ForeignKey(Grade, on_delete=models.CASCADE, related_name='homeworks')

    def __str__(self):
        return self.title

class Parent(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, related_name='parent_profile')
    phone_number = models.CharField(max_length=15)
    address = models.TextField()

    def __str__(self):
        return self.user.get_full_name()






class TeacherSubjectAssignment(models.Model):
    teacher = models.ForeignKey(Teacher, on_delete=models.CASCADE)
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    grade = models.ForeignKey(Grade, on_delete=models.CASCADE)









from django.db import models
from django.conf import settings

class Complaint(models.Model):
    TOPIC_CHOICES = [
        ('academic', 'Academic'),
        ('behavior', 'Behavior'),
        ('facility', 'Facility'),
        ('other', 'Other'),
    ]

    topic = models.CharField(max_length=100, choices=TOPIC_CHOICES)
    description = models.TextField()
    complainant = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    date_filed = models.DateTimeField(auto_now_add=True)
    is_resolved = models.BooleanField(default=False)
    resolution_date = models.DateTimeField(null=True, blank=True)
    complainant_role = models.CharField(max_length=10)  # new field to store the role

    def __str__(self):
        return f"{self.topic} - {self.complainant.username} ({self.complainant_role})"

















from django.db import models
from django.utils import timezone
from django.contrib.auth import get_user_model
import math


class AttendanceT(models.Model):
    ATTENDANCE_STATUS = [
        (0, 'Absent'),
        (1, 'Present'),
    ]
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='attendances')
    date = models.DateField(default=timezone.now)
    status = models.IntegerField(choices=ATTENDANCE_STATUS)
    recorded_at = models.DateTimeField(auto_now_add=True)
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)

    def __str__(self):
        return f"{self.user.username} - {self.date} - {self.get_status_display()}"

class Coordinates(models.Model):
    latitude = models.FloatField()
    longitude = models.FloatField()
    radius = models.FloatField(default=5)  # 5 meter radius

    def __str__(self):
        return f"({self.latitude}, {self.longitude})"

    def is_within_boundary(self, lat, lon):
        R = 6371000  # Earth's radius in meters
        
        lat1, lon1 = math.radians(self.latitude), math.radians(self.longitude)
        lat2, lon2 = math.radians(lat), math.radians(lon)
        
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        
        a = (math.sin(dlat/2)**2 + 
             math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2)
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
        
        distance = R * c
        
        return distance <= self.radius






















class Chapter(models.Model):
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name='chapters')
    name = models.CharField(max_length=255)
    page_number = models.IntegerField()
    date_added = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"{self.subject.name} - {self.name}"

    @property
    def completion_percentage(self):
        total_tasks = self.tasks.count()
        completed_tasks = self.tasks.filter(is_completed=True).count()
        return (completed_tasks / total_tasks) * 100 if total_tasks > 0 else 0

class Task(models.Model):
    chapter = models.ForeignKey(Chapter, on_delete=models.CASCADE, related_name='tasks')
    title = models.CharField(max_length=255)
    description = models.TextField()
    date_added = models.DateTimeField(auto_now_add=True)
    completion_date = models.DateField(null=True, blank=True)
    is_completed = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.chapter.name} - {self.title}"