# File: your_app/management/commands/ vg.py

from django.core.management.base import BaseCommand
from django.utils import timezone
from django.db import transaction
from jjapp.models import Student, Attendance
import random

class Command(BaseCommand):
    help = 'Generates attendance records for all students for the last 30 days'

    def handle(self, *args, **kwargs):
        today = timezone.now().date()
        thirty_days_ago = today - timezone.timedelta(days=30)

        students = Student.objects.all()
        
        with transaction.atomic():
            for student in students:
                self.stdout.write(f"Generating attendance for student: {student}")
                for day in range(30):
                    date = thirty_days_ago + timezone.timedelta(days=day)
                    
                    # Check if attendance record already exists
                    if not Attendance.objects.filter(student=student, date=date).exists():
                        # Generate random attendance status (0 for absent, 1 for present)
                        # You can adjust the weights to change the probability of presence/absence
                        status = random.choices([0 ,1], weights=[20, 80])[0]
                        
                        Attendance.objects.create(
                            student=student,
                            date=date,
                            status=status
                        )
                        self.stdout.write(f"Created attendance for {student} on {date}: {'Present' if status else 'Absent'}")
                    else:
                        self.stdout.write(f"Attendance record already exists for {student} on {date}")

        self.stdout.write(self.style.SUCCESS('Successfully generated attendance records for all students'))